CREATE INDEX LookUpSales ON Sales (customerID, dayDate);
