START TRANSACTION ISOLATION LEVEL SERIALIZABLE;
UPDATE Customers 
SET custName = NewCustomers.custName, address = NewCustomers.address, joinDate = NewCustomers.joinDate
FROM NewCustomers
WHERE Customers.customerID = NewCustomers.customerID;

INSERT INTO Customers (customerID, custName, address, joinDate, amountOwed, lastPaidDate, status)
SELECT customerID, custName, address, joinDate, 0, NULL, 'L'
FROM NewCustomers
WHERE NOT EXISTS (
SELECT * FROM CUSTOMERS WHERE Customers.customerID = NewCustomers.customerID);
COMMIT;
