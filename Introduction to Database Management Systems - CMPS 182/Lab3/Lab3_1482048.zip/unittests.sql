/* Elicits Errors For All Foreign Constraints*/
INSERT INTO Sales VALUES (112, 1001, 1, '2018-01-15', 15.20, 1);
INSERT INTO Sales VALUES (111, 1007, 1, '2018-01-15', 15.20, 1);
INSERT INTO Sales VALUES (111, 1001, 5, '2018-01-15', 15.20, 1);
INSERT INTO Sales VALUES (111, 1001, 1, '2018-01-02', 15.20, 1);
INSERT INTO Payments VALUES(1007, 'John Smith', '2018-01-06', 15.20, FALSE);

/*General Constraint 1, error, success*/
UPDATE Customers
SET amountOwed = -5
WHERE customerID = 1001;

UPDATE Customers
SET amountOwed = 5
WHERE customerID = 1001;

/*General Constraint 2, error, succes*/
UPDATE Sales
SET paidPrice = 2, quantity = 2
WHERE (paidPrice*quantity) >= 10;

UPDATE Sales
SET paidPrice = 5, quantity = 3
WHERE (paidPrice*quantity) >= 10;

/*General Constraint 3, error, success*/
UPDATE Customers
SET lastPaidDate = NULL, status = 'H'
WHERE customerID = 1102;

UPDATE Customers
SET lastPaidDate = NULL, status = 'L'
WHERE customerID = 1102;
