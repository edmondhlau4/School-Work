SELECT s.customerID, cl.totalClearedPayments, COUNT (DISTINCT s.productID) AS numDiffProducts
FROM Sales s, Payments p, ClearedPayments cl, Customers c
WHERE s.customerID = p.customerID  
        AND p.customerID = cl.customerID
	AND cl.customerID = c.customerID
	AND cl.totalClearedPayments > c.amountOwed
GROUP BY s.customerID, cl.totalClearedPayments
HAVING COUNT (DISTINCT s.productID) >= 3;

/* BEFORE DELETE
customerID | totalClearedPayments | numdiffproducts
   1001    |       269.11         |        5       
   1002    |       364.56         |        5
   1004    |       494.40         |        3
   1005    |       249.99         |        3
*/


DELETE FROM Payments
WHERE customerID = 1002
AND paidDate = '2018-02-19';

DELETE FROM Payments
WHERE customerID = 1004
AND paidDate = '2018-02-04';

SELECT s.customerID, cl.totalClearedPayments, COUNT (DISTINCT s.productID) as numDiffProducts
FROM Sales s, Payments p, ClearedPayments cl, Customers c
WHERE s.customerID = p.customerID
	AND p.customerID = cl.customerID
	AND cl.customerID = c.customerID
	AND cl.totalClearedPayments > c.amountOwed
GROUP BY s.customerID, cl.totalClearedPayments
HAVING COUNT (DISTINCT s.productID) >= 3;


/* AFTER DELETE
customerID | totalClearedPayments | numdiffproducts
   1001    |	    269.11        |       5
   1002    |        352.24        |       5
   1005    |        249.99        |       3
*/

