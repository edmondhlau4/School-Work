ALTER TABLE Customers
ADD CONSTRAINT owed_is_not_negative
CHECK (amountOwed >= 0);

ALTER TABLE Sales
ADD CONSTRAINT revenue
CHECK (paidPrice*quantity >= 10);

ALTER TABLE Customers
ADD CHECK (lastPaidDate IS NULL AND status = 'L' OR lastPaidDate IS NOT NULL);
