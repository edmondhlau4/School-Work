ALTER TABLE Sales
ADD CONSTRAINT fk_productID
FOREIGN KEY (productID) REFERENCES Products (productID);

ALTER TABLE Sales
ADD CONSTRAINT fk_customerID
FOREIGN KEY (customerID) REFERENCES Customers(customerID);

ALTER TABLE Sales
ADD CONSTRAINT fk_storeID
FOREIGN KEY (storeID) REFERENCES Stores(storeID);

ALTER TABLE Sales
ADD CONSTRAINT fk_dayDate
FOREIGN KEY (dayDate) REFERENCES Days(dayDate);

ALTER TABLE Payments
ADD CONSTRAINT fk_customerID
FOREIGN KEY (customerID) REFERENCES Customers(customerID);
