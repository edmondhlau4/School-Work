SELECT productID, productName
FROM products
WHERE productName LIKE 'Intelligent%'
ORDER BY productName asc;
